<?php
namespace WRO\Database\Procedures;

abstract class StoredProcedure {
	protected function __construct() {}
};