(function () {
    'use strict';

    angular
        .module('WRO', [
            'ui.bootstrap',
            'angularUtils.directives.dirPagination',
            'ngMessages',
            'toastr',
            'ngFileUpload'
        ]);
})();